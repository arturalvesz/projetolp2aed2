package edu.ufp.lp2aed2;

import java.security.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import edu.princeton.cs.algs4.ST;
import edu.ufp.lp2aed2.model.Historic;
import edu.ufp.lp2aed2.model.Node;
import edu.ufp.lp2aed2.model.Role;
import edu.ufp.lp2aed2.model.User;
import edu.ufp.lp2aed2.model.Vehicle;
import edu.ufp.lp2aed2.model.VehicleType;
import edu.ufp.lp2aed2.model.Way;
import edu.ufp.lp2aed2.model.WebType;

class Lp2aed2ApplicationTests {
	
	public static Database database = new Database();

	public static ST<Integer, User> populateAndCheckUsers() {
		ST<Integer, Vehicle> vehicles = new ST<>();
		Vehicle vehicle = new Vehicle("VW", "Golf", VehicleType.COMBUSTION_CAR, WebType.ROAD, false);
		vehicles.put(1, vehicle);
		
		ST<Integer, Historic> historicSt = new ST<>();
		Historic historic = new Historic(new Date(), "Add new vehicle");
		historicSt.put(1, historic);
		User user = new User("Artur", Role.ADMIN, vehicles, historicSt);
		
		database.insertUser(user);
		
		return database.listAllUsers();
	}
	
	public static List<Node> populateAndChecNodes(){
		List<Way> ways = new ArrayList<>();
		
		Way way1 = new Way(WebType.ROAD, 22L, "vertical", null, null, null);
		Way way2 = new Way(WebType.ROAD, 33L, "horizontal", null, null, null);
		ways.add(way1);
		ways.add(way2);
		
		ST<Integer, String> nodeTags = new ST<>();
		nodeTags.put(1, "Node tag 1");
		nodeTags.put(2, "Node tag 2");
		
		Node node = new Node(WebType.ROAD, nodeTags, ways);
		
		database.insertNode(node);
		
		return database.listAllNodes();
		
	}

}
