package edu.ufp.lp2aed2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 *Testing file
 */

@SpringBootTest
class Lp2aed2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
