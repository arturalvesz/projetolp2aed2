package edu.ufp.lp2aed2.model;

import javax.persistence.*;
import java.util.Date;

/**
 *
 * Getters and setters of the class VehicleSpot
 *
 */

@Entity
@Table(name = "vehicle_spot")
public class VehicleSpot {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    private Integer km;

    private Date creationDate;

    private String direction;

    private Integer speed;

    @ManyToOne
    private Vehicle vehicle;

    @ManyToOne
    private Node node;

    @ManyToOne
    private Way way;

    @ManyToOne
    private Pol pol;

    public VehicleSpot() {
    }

    public VehicleSpot(Integer km, String direction, Integer speed, Vehicle vehicle, Node node, Way way, Pol pol) {
        this.km = km;
        this.creationDate = new Date();
        this.direction = direction;
        this.speed = speed;
        this.vehicle = vehicle;
        this.node = node;
        this.way = way;
        this.pol = pol;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getKm() {
        return km;
    }

    public void setKm(Integer km) {
        this.km = km;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public Integer getSpeed() {
        return speed;
    }

    public void setSpeed(Integer speed) {
        this.speed = speed;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public Node getNode() {
        return node;
    }

    public void setNode(Node node) {
        this.node = node;
    }

    public Way getWay() {
        return way;
    }

    public void setWay(Way way) {
        this.way = way;
    }

    public Pol getPol() {
        return pol;
    }

    public void setPol(Pol pol) {
        this.pol = pol;
    }
}
