package edu.ufp.lp2aed2.model;

import javax.persistence.*;
import java.util.HashMap;

/**
 *
 * Getters and setters of the class WayTag
 *
 */


@Entity
@Table(name = "way_tag")
public class WayTag {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    private String description;

    @ManyToOne
    private TagType tagType;

    @ManyToOne
    private Way way;

    public WayTag() {
    }

    public WayTag(String description, TagType tagType, Way way) {
        this.description = description;
        this.tagType = tagType;
        this.way = way;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public TagType getTagType() {
        return tagType;
    }

    public void setTagType(TagType tagType) {
        this.tagType = tagType;
    }

    public Way getWay() {
        return way;
    }

    public void setWay(Way way) {
        this.way = way;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
