package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.Role;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * Repository for Role using CRUDRepository interface methods to create, read, update and delete
 *
 */



@Repository
public interface RoleRepository extends CrudRepository<Role, Integer> {
}
