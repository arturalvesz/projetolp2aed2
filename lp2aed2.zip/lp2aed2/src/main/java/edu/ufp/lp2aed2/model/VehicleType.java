package edu.ufp.lp2aed2.model;

public enum VehicleType {

	ELECTRIC_CAR, COMBUSTION_CAR, ELECTRIC_BIKE, BIKE

}
