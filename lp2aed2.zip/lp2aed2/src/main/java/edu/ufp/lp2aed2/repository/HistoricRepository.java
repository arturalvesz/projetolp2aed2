package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.Historic;
import edu.ufp.lp2aed2.model.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 *
 * Repository for Historic using CRUDRepository interface methods to create, read, update and delete
 *
 */


@Repository
public interface HistoricRepository extends CrudRepository<Historic, Integer> {
    void deleteAllByUser(User user);//delete all the historic of a user
    List<Historic> findAllByUser(User user);//find all the historic of a user
}
