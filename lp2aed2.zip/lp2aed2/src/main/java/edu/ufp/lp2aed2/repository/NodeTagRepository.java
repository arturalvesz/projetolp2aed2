package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.NodeTag;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * Repository for NodeTag using CRUDRepository interface methods to create, read, update and delete
 *
 */



@Repository
public interface NodeTagRepository extends CrudRepository<NodeTag, Integer> {
}
