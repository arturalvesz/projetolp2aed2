package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.Node;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * Repository for Node using CRUDRepository interface methods to create, read, update and delete
 *
 */


@Repository
public interface NodeRepository extends CrudRepository<Node, Integer> {
}
