package edu.ufp.lp2aed2.service;

import edu.ufp.lp2aed2.model.*;
import edu.ufp.lp2aed2.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 * Implementation of all the services that are going to be used
 */


@Service
public class ServiceImpl implements IService{

    private HistoricRepository historicRepository;

    private NodeRepository nodeRepository;

    private NodeTagRepository nodeTagRepository;

    private PolRepository polRepository;

    private PolTypeRepository polTypeRepository;

    private RoadWorkRepository roadWorkRepository;

    private RoadWorkTypeRepository roadWorkTypeRepository;

    private RoleRepository roleRepository;

    private TagTypeRepository tagTypeRepository;

    private UserRepository userRepository;

    private VehicleRepository vehicleRepository;

    private VehicleSpotRepository vehicleSpotRepository;

    private VehicleTypeRepository vehicleTypeRepository;

    private WayRepository wayRepository;

    private WayTagRepository wayTagRepository;

    private WebTypeRepository webTypeRepository;

    @Autowired
    public ServiceImpl(HistoricRepository historicRepository, NodeRepository nodeRepository, NodeTagRepository nodeTagRepository, PolRepository polRepository, PolTypeRepository polTypeRepository, RoadWorkRepository roadWorkRepository, RoadWorkTypeRepository roadWorkTypeRepository, RoleRepository roleRepository, TagTypeRepository tagTypeRepository, UserRepository userRepository, VehicleRepository vehicleRepository, VehicleSpotRepository vehicleSpotRepository, VehicleTypeRepository vehicleTypeRepository, WayRepository wayRepository, WayTagRepository wayTagRepository, WebTypeRepository webTypeRepository) {
        this.historicRepository = historicRepository;
        this.nodeRepository = nodeRepository;
        this.nodeTagRepository = nodeTagRepository;
        this.polRepository = polRepository;
        this.polTypeRepository = polTypeRepository;
        this.roadWorkRepository = roadWorkRepository;
        this.roadWorkTypeRepository = roadWorkTypeRepository;
        this.roleRepository = roleRepository;
        this.tagTypeRepository = tagTypeRepository;
        this.userRepository = userRepository;
        this.vehicleRepository = vehicleRepository;
        this.vehicleSpotRepository = vehicleSpotRepository;
        this.vehicleTypeRepository = vehicleTypeRepository;
        this.wayRepository = wayRepository;
        this.wayTagRepository = wayTagRepository;
        this.webTypeRepository = webTypeRepository;
    }

    //Create a new role
    @Override
    public void createRole(Integer key, String description) {
        this.roleRepository.save(new Role(key, description));
    }

    //Create a new user
    @Override
    public void createUser(String userName, Role role) {
        this.userRepository.save(new User(userName, role));
    }

    //Create a new Historic
    @Override
    public void createHistoricRow(User user, String action) {
        this.historicRepository.save(new Historic(user, action));
    }

    //Create a new vehicle
    @Override
    public void createVehicle(String brand, String model, User user, VehicleType vehicleType) {
        this.vehicleRepository.save(new Vehicle(brand, model, vehicleType, user));
    }

    //Create a new vehicle spot
    @Override
    public void createVehicleSpot(Integer km, String direction, Integer speed, Vehicle vehicle, Node node, Way way, Pol pol) {
        this.vehicleSpotRepository.save(new VehicleSpot(km, direction, speed, vehicle, node, way, pol));
    }

    //Create a new vehicle type
    @Override
    public void createVehicleType(Integer key, String description) {
        this.vehicleTypeRepository.save(new VehicleType(key, description));
    }

    //Create a new web type
    @Override
    public void createWebType(Integer key, String description) {
        this.webTypeRepository.save(new WebType(key, description));
    }

    //Create a new node
    @Override
    public void createNode(Double latitude, Double longitude, WebType webType) {
        this.nodeRepository.save(new Node(latitude, longitude, webType));
    }

    //Create a new way
    @Override
    public void createWay(Double distance, WebType webType) {
        this.wayRepository.save(new Way(distance, webType));
    }

    //Create a new way tag
    @Override
    public void createWayTag(String description, Way way, TagType tagType) {
        this.wayTagRepository.save(new WayTag(description, tagType, way));
    }

    //Create a new PoI type
    @Override
    public void createPolType(Integer key, String description) {
        this.polTypeRepository.save(new PolType(key, description));
    }

    //Create a new PoI
    @Override
    public void createPol(Double latitude, Double longitude, PolType polType, WebType webType) {
        this.polRepository.save(new Pol(latitude, longitude, polType, webType));
    }

    //Create a new tag type
    @Override
    public void createTagType(Integer key, String description) {
        this.tagTypeRepository.save(new TagType(key, description));
    }

    //Create a new node tag
    @Override
    public void createNodeTag(String description, Node node, TagType tagType) {
        this.nodeTagRepository.save(new NodeTag(description, tagType, node));
    }

    //Create a new roadwork type
    @Override
    public void createRoadWorkType(Integer key, String description) {
        this.roadWorkTypeRepository.save(new RoadWorkType(key, description));
    }

    //Create a new roadwork
    @Override
    public void createRoadWork(String details, Way way, RoadWorkType roadWorkType) {
        this.roadWorkRepository.save(new RoadWork(details, roadWorkType, way));
    }

    //Update the user
    @Override
    public User updateUser(User user) {
        if(this.userRepository.findById(user.getUserId()).isPresent()){
            return this.userRepository.save(user);
        }else{
            return null;
        }
    }

    //Get the user by is Id
    @Override
    public User getUserById(Integer id) {
        return this.userRepository.findById(id).get();
    }

    //Get all users on the database
    @Override
    public List<User> getAllUsers() {
        return (List<User>) this.userRepository.findAll();
    }

    //Delete a user by is Id
    @Override
    public void deleteUserById(Integer id) {
        //Check if the Id exists on the database
        if(this.userRepository.findById(id).isPresent()){
            User user = this.userRepository.findById(id).get();
            StringBuilder text = new StringBuilder();
            text.append(user.getUserName()).append(": ").append(user.getRole().getDescription());
            if(this.getAllHistoricByUserId(id) != null){
                text.append("- Historic { ");
                for(Historic x : this.getAllHistoricByUserId(id)){
                    text.append(x.getAction()).append(": ").append(x.getCreationDate()).append(";");
                }
                text.append("}");
            }
            //check if the user has any vehicles
            if(this.getAllVehiclesByUserId(id) != null){
                text.append("- Vehicles { ");
                for(Vehicle y : this.getAllVehiclesByUserId(id)){
                    text.append(y.getBrand()).append(", ").append(y.getModel()).append(", ").append(y.getVehicleType().getDescription()).append(";");
                }
                text.append("}");
            }
            text.append(";\n");
            this.userRepository.delete(user);
        }
    }

    //Delete all the historic of an user by is Id
    @Override
    public void deleteAllHistoricByUserId(Integer userId) {
        if(this.userRepository.findById(userId).isPresent()){
            this.historicRepository.deleteAllByUser(this.userRepository.findById(userId).get());
        }
    }

    //Get all the historic of an user by is Id
    @Override
    public List<Historic> getAllHistoricByUserId(Integer userId) {
        return this.historicRepository.findAllByUser(this.userRepository.findById(userId).get());
    }

    //Delete a vehicle by is Id
    @Override
    public void deleteVehicleById(Integer id) {
        if(this.vehicleRepository.findById(id).isPresent()){
            this.vehicleRepository.deleteById(id);
        }
    }

    //Delete all the vehicles of an user by is Id
    @Override
    public void deleteAllVehiclesByUserId(Integer userId) {
        if(this.userRepository.findById(userId).isPresent()){
            this.vehicleRepository.deleteAllByUser(this.userRepository.findById(userId).get());
        }
    }

    //Get vehicle by is Id
    @Override
    public Vehicle getVehicleById(Integer id) {
        return this.vehicleRepository.findById(id).get();
    }

    //Get all the vehicles of an user by is Id
    @Override
    public List<Vehicle> getAllVehiclesByUserId(Integer userId) {
        if(this.userRepository.findById(userId).isPresent()){
            return this.vehicleRepository.findAllByUser(this.userRepository.findById(userId).get());
        }else{
            return null;
        }
    }

    //Update a vehicle
    @Override
    public Vehicle updateVehicle(Vehicle vehicle) {
        if(this.vehicleRepository.findById(vehicle.getVehicleId()).isPresent()){
            return this.vehicleRepository.save(vehicle);
        }else{
            return null;
        }
    }
}
