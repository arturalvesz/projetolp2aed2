package edu.ufp.lp2aed2.model;

import javax.persistence.*;


/**
 *
 * Getters and setters of the class PoI
 *
 */


@Entity
@Table(name = "pol")
public class Pol {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer polId;

    private Double latitude;

    private Double longitude;

    @ManyToOne
    private PolType polType;

    @ManyToOne
    private WebType webType;

    public Pol() {
    }

    public Pol(Double latitude, Double longitude, PolType polType, WebType webType) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.polType = polType;
        this.webType = webType;
    }

    public Integer getPolId() {
        return polId;
    }

    public void setPolId(Integer polId) {
        this.polId = polId;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public PolType getPolType() {
        return polType;
    }

    public void setPolType(PolType polType) {
        this.polType = polType;
    }

    public WebType getWebType() {
        return webType;
    }

    public void setWebType(WebType webType) {
        this.webType = webType;
    }
}
