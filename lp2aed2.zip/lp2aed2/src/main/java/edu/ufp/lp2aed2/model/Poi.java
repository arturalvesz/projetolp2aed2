package edu.ufp.lp2aed2.model;

import edu.princeton.cs.algs4.BST;

public class Poi extends BST<Integer, String>{
	
	private WebType webType;
	
	private PoiType poiType;

	public Poi() {

	}

	/**
	 * @param webType
	 * @param poiType
	 */
	public Poi(WebType webType, PoiType poiType) {
		super();
		this.webType = webType;
		this.poiType = poiType;
	}

	/**
	 * @return the webType
	 */
	public WebType getWebType() {
		return webType;
	}

	/**
	 * @param webType the webType to set
	 */
	public void setWebType(WebType webType) {
		this.webType = webType;
	}

	/**
	 * @return the poiType
	 */
	public PoiType getPoiType() {
		return poiType;
	}

	/**
	 * @param poiType the poiType to set
	 */
	public void setPoiType(PoiType poiType) {
		this.poiType = poiType;
	}
		
}
