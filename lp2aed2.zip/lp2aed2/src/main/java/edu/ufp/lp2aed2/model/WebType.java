package edu.ufp.lp2aed2.model;

public enum WebType {
	
	ROAD, OFFROAD, BICYCLE

}
