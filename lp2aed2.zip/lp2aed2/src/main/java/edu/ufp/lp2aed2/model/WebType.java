package edu.ufp.lp2aed2.model;

import javax.persistence.*;
import java.util.HashMap;


/**
 *
 * Getters and setters of the class WebType
 *
 */


@Entity
@Table(name = "web_type")
public class WebType {

    @Id
    private Integer id;

    private String description;

    public WebType() {
    }

    public WebType(Integer id, String description) {
        this.id = id;
        this.description = description;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
