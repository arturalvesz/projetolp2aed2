package edu.ufp.lp2aed2.service;

import edu.ufp.lp2aed2.model.*;

import java.util.List;

public interface IService {
    //CREATES
    void createRole(Integer key, String description);
    void createUser(String userName, Role role);
    void createHistoricRow(User user, String action);
    void createVehicle(String brand, String model, User user, VehicleType vehicleType);
    void createVehicleSpot(Integer km, String direction, Integer speed, Vehicle vehicle, Node node, Way way, Pol pol);
    void createVehicleType(Integer key, String description);
    void createWebType(Integer key, String description);
    void createNode(Double latitude, Double longitude, WebType webType);
    void createWay(Double distance, WebType webType);
    void createWayTag(String description, Way way, TagType tagType);
    void createPolType(Integer key, String description);
    void createPol(Double latitude, Double longitude, PolType polType, WebType webType);
    void createTagType(Integer key, String description);
    void createNodeTag(String description, Node node, TagType tagType);
    void createRoadWorkType(Integer key, String description);
    void createRoadWork(String details, Way way, RoadWorkType roadWorkType);

    //USER METHODS
    User updateUser(User user);
    User getUserById(Integer id);
    List<User> getAllUsers();
    void deleteUserById(Integer id);

    //HISTORIC METHODS
    void deleteAllHistoricByUserId(Integer userId);
    List<Historic> getAllHistoricByUserId(Integer userId);

    //VEHICLE METHODS
    void deleteVehicleById(Integer id);
    void deleteAllVehiclesByUserId(Integer userId);
    Vehicle getVehicleById(Integer id);
    List<Vehicle> getAllVehiclesByUserId(Integer userId);
    Vehicle updateVehicle(Vehicle vehicle);

}
