package edu.ufp.lp2aed2.model;

import javax.persistence.*;

/**
 *
 * Getters and setters of the class Way
 *
 */


@Entity
@Table(name = "way")
public class Way {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer wayId;

    private Double distance;

    @ManyToOne
    private WebType webType;

    public Way() {
    }

    public Way(Double distance, WebType webType) {
        this.distance = distance;
        this.webType = webType;
    }

    public Integer getWayId() {
        return wayId;
    }

    public void setWayId(Integer wayId) {
        this.wayId = wayId;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public WebType getWebType() {
        return webType;
    }

    public void setWebType(WebType webType) {
        this.webType = webType;
    }
}
