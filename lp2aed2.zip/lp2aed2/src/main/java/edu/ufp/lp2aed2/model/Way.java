package edu.ufp.lp2aed2.model;

import java.util.List;

import edu.princeton.cs.algs4.ST;

public class Way {
	
	private WebType webType;
	
	private Long distance;
	
	private String orientation;
	
	private List<Node> connectedNodes;
	
	private ST wayTags;
	
	private ST<Integer, String> roadWorks;
	
	public Way() {

	}

	/**
	 * @param webType
	 * @param distance
	 * @param orientation
	 * @param connectedNodes
	 * @param wayTags
	 * @param roadWorks
	 */
	public Way(WebType webType, Long distance, String orientation, List<Node> connectedNodes, ST wayTags,
			ST<Integer, String> roadWorks) {
		super();
		this.webType = webType;
		this.distance = distance;
		this.orientation = orientation;
		this.connectedNodes = connectedNodes;
		this.wayTags = wayTags;
		this.roadWorks = roadWorks;
	}


	/**
	 * @return the webType
	 */
	public WebType getWebType() {
		return webType;
	}

	/**
	 * @param webType the webType to set
	 */
	public void setWebType(WebType webType) {
		this.webType = webType;
	}

	/**
	 * @return the distance
	 */
	public Long getDistance() {
		return distance;
	}

	/**
	 * @param distance the distance to set
	 */
	public void setDistance(Long distance) {
		this.distance = distance;
	}

	/**
	 * @return the orientation
	 */
	public String getOrientation() {
		return orientation;
	}

	/**
	 * @param orientation the orientation to set
	 */
	public void setOrientation(String orientation) {
		this.orientation = orientation;
	}

	/**
	 * @return the connectedNodes
	 */
	public List<Node> getConnectedNodes() {
		return connectedNodes;
	}

	/**
	 * @param connectedNodes the connectedNodes to set
	 */
	public void setConnectedNodes(List<Node> connectedNodes) {
		this.connectedNodes = connectedNodes;
	}

	/**
	 * @return the wayTags
	 */
	public ST getWayTags() {
		return wayTags;
	}

	/**
	 * @param wayTags the wayTags to set
	 */
	public void setWayTags(ST wayTags) {
		this.wayTags = wayTags;
	}

	/**
	 * @return the roadWorks
	 */
	public ST<Integer, String> getRoadWorks() {
		return roadWorks;
	}

	/**
	 * @param roadWorks the roadWorks to set
	 */
	public void setRoadWorks(ST<Integer, String> roadWorks) {
		this.roadWorks = roadWorks;
	}

}
