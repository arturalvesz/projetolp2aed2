package edu.ufp.lp2aed2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import Utils.Utils;
import edu.princeton.cs.algs4.ST;
import edu.ufp.lp2aed2.model.Grafo;
import edu.ufp.lp2aed2.model.Node;
import edu.ufp.lp2aed2.model.Poi;
import edu.ufp.lp2aed2.model.User;
import edu.ufp.lp2aed2.model.Way;
import edu.ufp.lp2aed2.model.WebType;

public class Database {

	/**
	 * @attribute users
	 * @comment each user has a name and a role with its description
	 */
	private ST<Integer, User> users;

	/**
	 * @attribute nodes
	 * @comment all database nodes
	 */
	private List<Node> nodes;

	/**
	 * @attribute ways
	 * @comment all database ways
	 */
	private ST<Integer, Way> ways;

	/**
	 * @attribute pois
	 * @comment all database points of interest
	 */
	private List<Poi> pois;

	/**
	 * @attribute userVehicleSpots
	 * @comment each spot arrived for each database user
	 */
	private ST<Integer, Grafo> userVehicleSpots;

	public Database() {
		super();
		this.users = new ST<>();
		this.nodes = new ArrayList<>();
		this.ways = new ST<>();
		this.pois = new ArrayList<>();
		this.userVehicleSpots = new ST<>();
	}

	/**
	 * @param users
	 * @param nodes
	 * @param ways
	 * @param pois
	 * @param userVehicleSpots
	 */
	public Database(ST<Integer, User> users, List<Node> nodes, ST<Integer, Way> ways, List<Poi> pois,
			ST<Integer, Grafo> userVehicleSpots) {
		super();
		this.users = users;
		this.nodes = nodes;
		this.ways = ways;
		this.pois = pois;
		this.userVehicleSpots = userVehicleSpots;
	}

	/**
	 * @param user
	 */
	public void insertUser(User user) {
		if (user != null) {
			Integer userKey = this.users.max() + 1;
			this.users.put(userKey, user);
		}
	}

	/**
	 * @param userKey
	 * @param user
	 */
	public void editUser(Integer userKey, User user) {
		if (user != null && userKey != null && this.users.contains(userKey)) {
			this.users.put(userKey, user);
		}
	}

	/**
	 * @param userKey
	 * @return
	 */
	public User findUser(Integer userKey) {
		if (userKey != null && this.users.contains(userKey)) {
			return this.users.get(userKey);
		} else {
			return null;
		}
	}

	/**
	 * @param userKey
	 * @throws IOException
	 */
	public void removeUser(Integer userKey) throws IOException {
		if (userKey != null && this.users.contains(userKey)) {
			User userToRemove = this.users.get(userKey);
			StringBuilder text = new StringBuilder();

			text.append(userToRemove.getName()).append(userToRemove.getRole()).append(userToRemove.getHistoric())
					.append(userToRemove.getVehicles());
			Utils.writeDeletedUsersInFile(text.toString());

			this.users.remove(userKey);
		}
	}

	/**
	 * @return
	 */
	public ST<Integer, User> listAllUsers() {
		return this.users;
	}

	/**
	 * @param node
	 */
	public void insertNode(Node node) {
		if (node != null) {
			this.nodes.add(node);
		}
	}

	/**
	 * @param nodeKey
	 * @param node
	 */
	public void editNode(Integer nodeKey, Node node) {
		if (nodeKey != null && node != null && this.nodes.contains(node)) {
			this.nodes.set(nodeKey, node);
		}
	}

	/**
	 * @param nodeKey
	 * @return
	 */
	public Node findNode(Integer nodeKey) {
		if (nodeKey != null) {
			return this.nodes.get(nodeKey);
		} else {
			return null;
		}
	}

	/**
	 * @param nodeKey
	 */
	public void removeNode(Integer nodeKey) {
		if (nodeKey != null) {
			this.nodes.remove(nodeKey);
		}
	}

	/**
	 * @return
	 */
	public List<Node> listAllNodes() {
		return this.nodes;
	}

	/**
	 * @param way
	 */
	public void insertWay(Way way) {
		if (way != null) {
			Integer wayKey = this.ways.max() + 1;
			this.ways.put(wayKey, way);
		}
	}

	/**
	 * @param wayKey
	 * @param way
	 */
	public void editWay(Integer wayKey, Way way) {
		if (way != null && wayKey != null && this.ways.contains(wayKey)) {
			this.ways.put(wayKey, way);
		}
	}

	/**
	 * @param wayKey
	 * @return
	 */
	public Way findWay(Integer wayKey) {
		if (wayKey != null && this.ways.contains(wayKey)) {
			return this.ways.get(wayKey);
		} else {
			return null;
		}
	}

	/**
	 * @param wayKey
	 */
	public void removeWay(Integer wayKey) {
		if (wayKey != null && this.ways.contains(wayKey)) {
			this.ways.remove(wayKey);
		}
	}

	/**
	 * @return
	 */
	public ST<Integer, Way> listAllWays() {
		return this.ways;
	}

	/**
	 * @param poi
	 */
	public void insertPoi(Poi poi) {
		if (poi != null) {
			this.pois.add(poi);
		}
	}

	/**
	 * @param poiKey
	 * @param poi
	 */
	public void editPoi(Integer poiKey, Node poi) {
		if (poiKey != null && poi != null && this.pois.contains(poi)) {
			this.nodes.set(poiKey, poi);
		}
	}

	/**
	 * @param poiKey
	 * @return
	 */
	public Poi findPoi(Integer poiKey) {
		if (poiKey != null) {
			return this.pois.get(poiKey);
		} else {
			return null;
		}
	}


	public void removePoi(Integer poiKey) {
		if (poiKey != null) {
			this.pois.remove(poiKey);
		}
	}

	/**
	 * @return
	 */
	public List<Poi> listAllPois() {
		return this.pois;
	}

	/**
	 * @param userVehicleSpot
	 */
	public void insertUserVehicleSpot(Grafo userVehicleSpot) {
		if (userVehicleSpot != null) {
			Integer userVehicleSpotKey = this.userVehicleSpots.max() + 1;
			this.userVehicleSpots.put(userVehicleSpotKey, userVehicleSpot);
		}
	}

	/**
	 * @param userVehicleSpotKey
	 * @param userVehicleSpot
	 */
	public void editUserVehicleSpot(Integer userVehicleSpotKey, Grafo userVehicleSpot) {
		if (userVehicleSpot != null && userVehicleSpotKey != null
				&& this.userVehicleSpots.contains(userVehicleSpotKey)) {
			this.userVehicleSpots.put(userVehicleSpotKey, userVehicleSpot);
		}
	}

	/**
	 * @param userVehicleSpotKey
	 * @return
	 */
	public Grafo findUserVehicleSpot(Integer userVehicleSpotKey) {
		if (userVehicleSpotKey != null && this.userVehicleSpots.contains(userVehicleSpotKey)) {
			return this.userVehicleSpots.get(userVehicleSpotKey);
		} else {
			return null;
		}
	}

	/**
	 * @param userVehicleSpotKey
	 */
	public void removeUserVehicleSpot(Integer userVehicleSpotKey) {
		if (userVehicleSpotKey != null && this.userVehicleSpots.contains(userVehicleSpotKey)) {
			this.userVehicleSpots.remove(userVehicleSpotKey);
		}
	}

	/**
	 * @return
	 */
	public ST<Integer, Grafo> listAllUserVehicleSpots() {
		return this.userVehicleSpots;
	}

	/**
	 * 
	 */
	public void now() {
		System.out.println("Users: " + this.listAllUsers());
		System.out.println("Nodes: " + this.listAllNodes());
		System.out.println("Ways: " + this.listAllWays());
		System.out.println("Pois: " + this.listAllPois());
		System.out.println("Spots: " + this.listAllUserVehicleSpots());
	}

	/**
	 * @param user
	 * @param begin
	 * @param ends
	 * @return
	 */
	public List<Poi> searchAllPoisByUser(User user, Date begin, Date ends) {
		List<Poi> returnList = new ArrayList<>();
		for (int i = 1; i < this.listAllUserVehicleSpots().size(); i++) {
			Grafo grafo = this.findUserVehicleSpot(i);
			if (grafo.getUser().equals(user) && grafo.getCreationDate().after(begin)
					&& grafo.getCreationDate().before(ends) && grafo.getPoi() != null) {
				returnList.add(grafo.getPoi());
			}
		}
		return returnList;
	}

	/**
	 * @param user
	 * @param begin
	 * @param ends
	 * @param webType
	 * @return
	 */
	public List<Poi> searchAllPoisByUserAndWebType(User user, Date begin, Date ends, WebType webType) {
		List<Poi> returnList = new ArrayList<>();
		for (int i = 1; i < this.listAllUserVehicleSpots().size(); i++) {
			Grafo grafo = this.findUserVehicleSpot(i);
			if (grafo.getUser().equals(user) && grafo.getCreationDate().after(begin)
					&& grafo.getCreationDate().before(ends) && grafo.getPoi() != null
					&& grafo.getPoi().getWebType().equals(webType)) {
				returnList.add(grafo.getPoi());
			}
		}
		return returnList;
	}

	/**
	 * @param user
	 * @param begin
	 * @param ends
	 * @return
	 */
	public List<Poi> searchNonePoisByUserAndWebType(User user, Date begin, Date ends, WebType webType) {
		List<Poi> poiList = new ArrayList<>();
		List<Poi> returnList = new ArrayList<>();

		for (int i = 1; i < this.listAllUserVehicleSpots().size(); i++) {
			Grafo grafo = this.findUserVehicleSpot(i);
			if (grafo.getUser().equals(user) && grafo.getCreationDate().after(begin)
					&& grafo.getCreationDate().before(ends) && grafo.getPoi() != null
					&& grafo.getPoi().getWebType().equals(webType)) {
				poiList.add(grafo.getPoi());
			}
		}

		poiList.forEach(element -> {
			if (!this.listAllPois().contains(element)) {
				returnList.add(element);
			}
		});

		return returnList;
	}

	/**
	 * @param user
	 * @param begin
	 * @param ends
	 * @return
	 */
	public List<Poi> searchNonePoisByUser(User user, Date begin, Date ends) {
		List<Poi> poiList = new ArrayList<>();
		List<Poi> returnList = new ArrayList<>();

		for (int i = 1; i < this.listAllUserVehicleSpots().size(); i++) {
			Grafo grafo = this.findUserVehicleSpot(i);
			if (grafo.getUser().equals(user) && grafo.getCreationDate().after(begin)
					&& grafo.getCreationDate().before(ends) && grafo.getPoi() != null) {
				poiList.add(grafo.getPoi());
			}
		}

		poiList.forEach(element -> {
			if (!this.listAllPois().contains(element)) {
				returnList.add(element);
			}
		});

		return returnList;
	}

}
