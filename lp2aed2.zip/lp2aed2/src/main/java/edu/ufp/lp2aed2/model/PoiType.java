package edu.ufp.lp2aed2.model;

public enum PoiType {
	
	CHARGE_STATION, FIRE_HYP, TRAFFIC_LIGHT

}
