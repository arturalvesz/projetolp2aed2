package edu.ufp.lp2aed2.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 *
 * Getters and setters of the class RoadWorkType
 *
 */

@Entity
@Table(name = "road_work_type")
public class RoadWorkType {

    @Id
    private Integer id;

    private String description;

    public RoadWorkType() {
    }

    public RoadWorkType(Integer id, String description) {
        this.id = id;
        this.description = description;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
