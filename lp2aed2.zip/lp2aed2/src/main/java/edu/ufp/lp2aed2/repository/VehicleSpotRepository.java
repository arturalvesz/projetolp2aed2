package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.VehicleSpot;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


/**
 *
 * Repository for VehicleSpot using CRUDRepository interface methods to create, read, update and delete
 *
 */


@Repository
public interface VehicleSpotRepository extends CrudRepository<VehicleSpot, Integer> {
}
