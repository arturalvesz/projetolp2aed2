package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.User;
import edu.ufp.lp2aed2.model.Vehicle;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 *
 * Repository for Vehicle using CRUDRepository interface methods to create, read, update and delete
 *
 */


@Repository
public interface VehicleRepository extends CrudRepository<Vehicle, Integer> {
    void deleteAllByUser(User user); //delete all the vehicles that a user owns
    List<Vehicle> findAllByUser(User user); //find all the vehicles that a user owns
}
