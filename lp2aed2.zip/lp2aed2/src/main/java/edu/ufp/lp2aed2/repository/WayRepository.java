package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.Way;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * Repository for Way using CRUDRepository interface methods to create, read, update and delete
 *
 */


@Repository
public interface WayRepository extends CrudRepository<Way, Integer> {
}
