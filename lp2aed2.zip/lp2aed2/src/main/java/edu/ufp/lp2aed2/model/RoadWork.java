package edu.ufp.lp2aed2.model;

import javax.persistence.*;

/**
 *
 * Getters and setters of the class RoadWork
 *
 */

@Entity
@Table(name = "road_work")
public class RoadWork {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    private String description;

    @ManyToOne
    private RoadWorkType type;

    @ManyToOne
    private Way way;

    public RoadWork() {
    }

    public RoadWork(String description, RoadWorkType type, Way way) {
        this.description = description;
        this.type = type;
        this.way = way;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public RoadWorkType getType() {
        return type;
    }

    public void setType(RoadWorkType type) {
        this.type = type;
    }

    public Way getWay() {
        return way;
    }

    public void setWay(Way way) {
        this.way = way;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
