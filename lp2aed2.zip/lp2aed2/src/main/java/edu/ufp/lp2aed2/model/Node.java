package edu.ufp.lp2aed2.model;

import javax.persistence.*;


/**
 *
 * Getters and setters of the class Node
 *
 */

@Entity
@Table(name = "node")
public class Node {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer nodeId;

    private Double latitude;

    private Double longitude;

    @ManyToOne
    private WebType webType;

    public Node() {
    }

    public Node(Double latitude, Double longitude, WebType webType) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.webType = webType;
    }

    public Integer getNodeId() {
        return nodeId;
    }

    public void setNodeId(Integer nodeId) {
        this.nodeId = nodeId;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public WebType getWebType() {
        return webType;
    }

    public void setWebType(WebType webType) {
        this.webType = webType;
    }
}
