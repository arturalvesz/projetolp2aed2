package edu.ufp.lp2aed2.model;

import java.util.List;

import edu.princeton.cs.algs4.BST;
import edu.princeton.cs.algs4.ST;

public class Node extends BST<Integer, String>{
	
	private WebType webType;
	
	private ST nodeTags;
	
	private List<Way> connectedWays;

	public Node() {
	}

	/**
	 * @param webType
	 * @param nodeTags
	 * @param pois
	 * @param connectedWays
	 */
	public Node(WebType webType, ST nodeTags, List<Way> connectedWays) {
		super();
		this.webType = webType;
		this.nodeTags = nodeTags;
		this.connectedWays = connectedWays;
	}

	/**
	 * @return the webType
	 */
	public WebType getWebType() {
		return webType;
	}

	/**
	 * @param webType the webType to set
	 */
	public void setWebType(WebType webType) {
		this.webType = webType;
	}

	/**
	 * @return the nodeTags
	 */
	public ST getNodeTags() {
		return nodeTags;
	}

	/**
	 * @param nodeTags the nodeTags to set
	 */
	public void setNodeTags(ST nodeTags) {
		this.nodeTags = nodeTags;
	}

	/**
	 * @return the connectedWays
	 */
	public List<Way> getConnectedWays() {
		return connectedWays;
	}

	/**
	 * @param connectedWays the connectedWays to set
	 */
	public void setConnectedWays(List<Way> connectedWays) {
		this.connectedWays = connectedWays;
	}

}
