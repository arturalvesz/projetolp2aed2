package edu.ufp.lp2aed2.model;

import javax.persistence.*;

/**
 *
 * Getters and setters of the class PoIType
 *
 */

@Entity
@Table(name = "pol_type")
public class PolType {

    @Id
    private Integer id;

    private String description;

    public PolType() {
    }

    public PolType(Integer id, String description) {
        this.id = id;
        this.description = description;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
