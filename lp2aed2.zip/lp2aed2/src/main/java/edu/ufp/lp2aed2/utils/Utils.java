package edu.ufp.lp2aed2.utils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Utils {

    private static final String FILENAME = "DeletedUsers.txt";

    public static void writeDeletedUsersInFile(String text) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(FILENAME, true));
        writer.append(text).append('\n');
    }
}
