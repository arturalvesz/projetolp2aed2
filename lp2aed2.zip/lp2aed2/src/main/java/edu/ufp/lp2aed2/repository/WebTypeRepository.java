package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.WebType;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * Repository for WebType using CRUDRepository interface methods to create, read, update and delete
 *
 */


@Repository
public interface WebTypeRepository extends CrudRepository<WebType, Integer> {
}
