package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.WayTag;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


/**
 *
 * Repository for WayTag using CRUDRepository interface methods to create, read, update and delete
 *
 */

@Repository
public interface WayTagRepository extends CrudRepository<WayTag, Integer> {
}
