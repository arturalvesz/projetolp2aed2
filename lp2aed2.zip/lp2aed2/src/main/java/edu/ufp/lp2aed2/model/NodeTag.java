package edu.ufp.lp2aed2.model;

import javax.persistence.*;

/**
 *
 * Getters and setters of the class NodeTag
 *
 */


@Entity
@Table(name = "node_tag")
public class NodeTag{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    private String description;

    @ManyToOne
    private TagType tagType;

    @ManyToOne
    private Node node;

    public NodeTag() {
    }

    public NodeTag(String description, TagType tagType, Node node) {
        this.description = description;
        this.tagType = tagType;
        this.node = node;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public TagType getTagType() {
        return tagType;
    }

    public void setTagType(TagType tagType) {
        this.tagType = tagType;
    }

    public Node getNode() {
        return node;
    }

    public void setNode(Node node) {
        this.node = node;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
