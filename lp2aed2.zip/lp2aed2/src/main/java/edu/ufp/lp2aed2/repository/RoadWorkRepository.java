package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.RoadWork;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


/**
 *
 * Repository for RoadWork using CRUDRepository interface methods to create, read, update and delete
 *
 */


@Repository
public interface RoadWorkRepository extends CrudRepository<RoadWork, Integer> {
}
