package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * Repository for User using CRUDRepository interface methods to create, read, update and delete
 *
 */



@Repository
public interface UserRepository extends CrudRepository<User, Integer> {
}
