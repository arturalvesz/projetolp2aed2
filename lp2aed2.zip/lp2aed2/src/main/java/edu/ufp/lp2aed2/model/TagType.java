package edu.ufp.lp2aed2.model;

import javax.persistence.*;

@Entity
@Table(name = "tag_type")
public class TagType {

    @Id
    private Integer id;

    private String description;

    public TagType() {
    }

    public TagType(Integer id, String description) {
        this.id = id;
        this.description = description;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
