package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.RoadWorkType;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


/**
 *
 * Repository for RoadWorkType using CRUDRepository interface methods to create, read, update and delete
 *
 */


@Repository
public interface RoadWorkTypeRepository extends CrudRepository<RoadWorkType, Integer> {
}
