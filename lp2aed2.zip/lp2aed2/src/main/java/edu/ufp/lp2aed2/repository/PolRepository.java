package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.Pol;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * Repository for PoI using CRUDRepository interface methods to create, read, update and delete
 *
 */


@Repository
public interface PolRepository extends CrudRepository<Pol, Integer> {
}
