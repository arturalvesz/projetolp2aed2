package edu.ufp.lp2aed2.model;

import javax.persistence.*;

/**
 *
 * Getters and setters of the class Vehicle
 *
 */

@Entity
@Table(name = "vehicle")
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer vehicleId;

    private String brand;

    private String model;

    @ManyToOne
    private VehicleType vehicleType;

    @ManyToOne
    private User owner;

    public Vehicle() {
    }

    public Vehicle(String brand, String model, VehicleType vehicleType, User owner) {
        this.brand = brand;
        this.model = model;
        this.vehicleType = vehicleType;
        this.owner = owner;
    }

    public Integer getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(Integer vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(VehicleType vehicleType) {
        this.vehicleType = vehicleType;
    }

    public User getOwner() {
        return owner;
    }

    public void setOwner(User owner) {
        this.owner = owner;
    }
}
