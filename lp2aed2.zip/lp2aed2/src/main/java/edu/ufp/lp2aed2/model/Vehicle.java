package edu.ufp.lp2aed2.model;

public class Vehicle {

	private String brand;

	private String model;

	private VehicleType vehicleType;

	private WebType webType;
	
	private Boolean isInUse;

	public Vehicle() {

	}

	/**
	 * @param brand
	 * @param model
	 * @param vehicleType
	 * @param webType
	 * @param isInUse
	 */
	public Vehicle(String brand, String model, VehicleType vehicleType, WebType webType, Boolean isInUse) {
		super();
		this.brand = brand;
		this.model = model;
		this.vehicleType = vehicleType;
		this.webType = webType;
		this.isInUse = isInUse;
	}

	/**
	 * @return the brand
	 */
	public String getBrand() {
		return brand;
	}

	/**
	 * @param brand the brand to set
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}

	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * @param model the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * @return the vehicleType
	 */
	public VehicleType getVehicleType() {
		return vehicleType;
	}

	/**
	 * @param vehicleType the vehicleType to set
	 */
	public void setVehicleType(VehicleType vehicleType) {
		this.vehicleType = vehicleType;
	}

	/**
	 * @return the webType
	 */
	public WebType getWebType() {
		return webType;
	}

	/**
	 * @param webType the webType to set
	 */
	public void setWebType(WebType webType) {
		this.webType = webType;
	}

	/**
	 * @return the isInUse
	 */
	public Boolean getIsInUse() {
		return isInUse;
	}

	/**
	 * @param isInUse the isInUse to set
	 */
	public void setIsInUse(Boolean isInUse) {
		this.isInUse = isInUse;
	}

}
