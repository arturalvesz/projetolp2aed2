package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.VehicleType;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


/**
 *
 * Repository for VehicleType using CRUDRepository interface methods to create, read, update and delete
 *
 */


@Repository
public interface VehicleTypeRepository extends CrudRepository<VehicleType, Integer> {
}
