package edu.ufp.lp2aed2.model;

import java.security.Timestamp;
import java.util.Date;

public class Grafo {
	
	private WebType webType;
	
	private User user;
	
	private Node node;
	
	private Way way;
	
	private Poi poi;
	
	private Date creationDate;
	
	private String direction;

	public Grafo() {

	}

	/**
	 * @param webType
	 * @param user
	 * @param node
	 * @param way
	 * @param poi
	 * @param creationDate
	 * @param direction
	 */
	public Grafo(WebType webType, User user, Node node, Way way, Poi poi, Date creationDate,
			String direction) {
		super();
		this.webType = webType;
		this.user = user;
		this.node = node;
		this.way = way;
		this.poi = poi;
		this.creationDate = creationDate;
		this.direction = direction;
	}

	/**
	 * @return the webType
	 */
	public WebType getWebType() {
		return webType;
	}

	/**
	 * @param webType the webType to set
	 */
	public void setWebType(WebType webType) {
		this.webType = webType;
	}

	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * @return the node
	 */
	public Node getNode() {
		return node;
	}

	/**
	 * @param node the node to set
	 */
	public void setNode(Node node) {
		this.node = node;
	}

	/**
	 * @return the way
	 */
	public Way getWay() {
		return way;
	}

	/**
	 * @param way the way to set
	 */
	public void setWay(Way way) {
		this.way = way;
	}

	/**
	 * @return the poi
	 */
	public Poi getPoi() {
		return poi;
	}

	/**
	 * @param poi the poi to set
	 */
	public void setPoi(Poi poi) {
		this.poi = poi;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the direction
	 */
	public String getDirection() {
		return direction;
	}

	/**
	 * @param direction the direction to set
	 */
	public void setDirection(String direction) {
		this.direction = direction;
	}

}
