package edu.ufp.lp2aed2.model;

public enum Role {

	ADMIN, BASIC, PREMIUM

}
