package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.PolType;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * Repository for PoIType using CRUDRepository interface methods to create, read, update and delete
 *
 */


@Repository
public interface PolTypeRepository extends CrudRepository<PolType, Integer> {
}
