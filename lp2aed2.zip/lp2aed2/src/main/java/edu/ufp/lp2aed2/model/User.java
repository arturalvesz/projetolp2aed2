package edu.ufp.lp2aed2.model;

import edu.princeton.cs.algs4.ST;

public class User {
	
	private String name;
	
	private Role role;
	
	private ST<Integer, Vehicle> vehicles;
	
	private ST<Integer, Historic> historic;

	/**
	 * @param name
	 * @param role
	 * @param vehicles
	 * @param historic
	 */
	public User(String name, Role role, ST<Integer, Vehicle> vehicles, ST<Integer, Historic> historic) {
		super();
		this.name = name;
		this.role = role;
		this.vehicles = vehicles;
		this.historic = historic;
	}

	public User() {
		super();
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the role
	 */
	public Role getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(Role role) {
		this.role = role;
	}

	/**
	 * @return the vehicles
	 */
	public ST<Integer, Vehicle> getVehicles() {
		return vehicles;
	}

	/**
	 * @param vehicles the vehicles to set
	 */
	public void setVehicles(ST<Integer, Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

	/**
	 * @return the historic
	 */
	public ST<Integer, Historic> getHistoric() {
		return historic;
	}

	/**
	 * @param historic the historic to set
	 */
	public void setHistoric(ST<Integer, Historic> historic) {
		this.historic = historic;
	}
		
}
