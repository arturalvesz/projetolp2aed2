package edu.ufp.lp2aed2.model;

import javax.persistence.*;


/**
 *
 * Getters and setters of the class User
 *
 */


@Entity
@Table(name = "user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer userId;

    private String userName;

    @ManyToOne
    private Role role;

    public User() {
    }

    public User(String userName, Role role) {
        this.userName = userName;
        this.role = role;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }
}
