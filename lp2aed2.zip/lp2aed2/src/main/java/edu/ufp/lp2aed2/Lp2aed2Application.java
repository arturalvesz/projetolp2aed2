package edu.ufp.lp2aed2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lp2aed2Application {

	public static void main(String[] args) {
		SpringApplication.run(Lp2aed2Application.class, args);
	}

}
