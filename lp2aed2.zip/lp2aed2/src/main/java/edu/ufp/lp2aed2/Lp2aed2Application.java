package edu.ufp.lp2aed2;

import edu.ufp.lp2aed2.model.Role;
import edu.ufp.lp2aed2.model.User;

public class Lp2aed2Application {

	public static void main(String[] args) {
//		Database db = new Database();
//		
//		db.getUsers().put(1, new User("Luís", new Role("admin")));
//		
//		System.out.println("Name" + "-----" + "Role");
//		
//		for(Integer i = 1; i <= db.getUsers().max(); i++) {
//			System.out.println(db.getUsers().get(i).getName() + "-----" + db.getUsers().get(i).getRole().getDescription());
//		}
		
	}

}
