package edu.ufp.lp2aed2.model;

import javax.persistence.*;
import java.util.Date;

/**
 *
 * Getters and setters of the class Historic
 *
 */

@Entity
@Table(name = "historic")
public class Historic {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    private String action;

    private Date creationDate;

    @ManyToOne
    private User user;

    public Historic() {
    }

    public Historic(User user, String action) {
        this.action = action;
        this.creationDate = new Date();
        this.user = user;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
