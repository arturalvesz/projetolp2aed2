package edu.ufp.lp2aed2.model;

import java.util.Date;

public class Historic {

	private Date creationDate;

	private String action;

	public Historic() {

	}

	/**
	 * @param creationDate
	 * @param action
	 */
	public Historic(Date creationDate, String action) {
		super();
		this.creationDate = creationDate;
		this.action = action;
	}

	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}

	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	/**
	 * @return the action
	 */
	public String getAction() {
		return action;
	}

	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
		this.action = action;
	}

}
