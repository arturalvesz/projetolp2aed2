package edu.ufp.lp2aed2.repository;

import edu.ufp.lp2aed2.model.TagType;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * Repository for Tag using CRUDRepository interface methods to create, read, update and delete
 *
 */

@Repository
public interface TagTypeRepository extends CrudRepository<TagType, Integer> {
}
